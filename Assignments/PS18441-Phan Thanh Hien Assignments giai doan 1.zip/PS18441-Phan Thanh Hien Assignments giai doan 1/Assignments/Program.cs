﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, Chon;
            do
            {

                Console.Write("0. Exit: ");
                Console.Write("-----MENU-----\n");
                Console.Write("1. Nhap danh sach hoc vien\n");
                Console.Write("2. Xuat danh sach hoc vien\n");
                Console.Write("3. Tim kiem hoc vien theo khoang diem\n");
                Console.Write("4. Tim kiem hoc vien theo hoc luc\n");
                Console.Write("5. Tim kiem hoc vien theo ma so va update\n");
                Console.Write("6. Sap xep hoc vien theo diem\n");
                Console.Write("7. Xuat 5 hoc vien co diem cao nhat\n");
                Console.Write("8. Tinh diem trung binh cua lop\n");
                Console.Write("9. Xuat DSHV co diem tren diem TB cua lop\n");
                Console.Write("10. Tong hop so hoc vien hoc luc\n");
                Console.Write("Chon: ");
                Chon=int.Parse(Console.ReadLine());
                switch (Chon)
                {
                    case 0: Console.Write("Bye Bye!"); break;//exit
                    case 1: Console.Write("Yeu cau 1\n"); break;//goi code yeu cau 1
                    case 2: Console.Write("Yeu cau 2\n"); break;//goi code yeu cau 2
                    case 3: Console.Write("Yeu cau 3\n"); break;//goi code yeu cau 3
                    case 4: Console.Write("Yeu cau 4\n"); break;//goi code yeu cau 4
                    case 5: Console.Write("Yeu cau 5\n"); break;//goi code yeu cau 5
                    case 6: Console.Write("Yeu cau 6\n"); break;//goi code yeu cau 6
                    case 7: Console.Write("Yeu cau 7\n"); break;//goi code yeu cau 7
                    case 8: Console.Write("Yeu cau 8\n"); break;//goi code yeu cau 8
                    case 9: Console.Write("Yeu cau 9\n"); break;//goi code yeu cau 9
                    case 10: Console.Write("Yeu cau 10\n"); break;//goi code yeu cau 10
                    default: Console.Write("Chon tu 0 -> 10\n"); break;
                }
            } while (Chon != 0);

        }
    }
}

