﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yeucau1
{
    class Program
    {
        static void Main(string[] args)
        {
            string hoten, diem, email;
            

            Console.WriteLine("Nhap ho ten: ");
            hoten = Console.ReadLine();

            Console.WriteLine("Nhap diem: ");
            diem = float.Parse(Console.ReadLine());

            Console.WriteLine("Nhap email: ");
            email = Console.ReadLine();

            Console.WriteLine("Thong tin sinh vien: hoten={0}, diem={1}, email={2}" + hoten, diem, email);
            Console.ReadKey();
        }
    }
}
