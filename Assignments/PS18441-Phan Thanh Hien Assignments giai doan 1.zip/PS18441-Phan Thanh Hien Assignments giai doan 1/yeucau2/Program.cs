﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yeucau2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("Xin moi nhap so Sinh vien :");
            n = int.Parse(Console.ReadLine());
            string[] hoTen = new string[n];
            float[] diem = new float[n];
            string[] email = new string[n];
            for (int i = 0; i < hoTen.Length; i++)
            {
                Console.WriteLine("NHap SV thu" + (i + 1));
                Console.Write("\nnhap ho ten: ");
                hoTen[i] = Console.ReadLine();

                Console.Write("nhap vao diem: ");
                diem[i] = float.Parse(Console.ReadLine());

                Console.Write("Nhap email:");
                email[i] = Console.ReadLine();
            }
            string[] hocLuc = new string[n];
            Console.WriteLine("-----------------Danh sach sinh vien vua nhap-------------------");
            Console.WriteLine("TT\thoten\temail\tdiem");
            for (int i = 0; i < hoTen.Length; i++)
            {
                Console.Write((i + 1) + "\t" + hoTen[i] + "\t" + email[i] + "\t" + diem[i] + "\t" + hocLuc[i]);

                if (diem[i] >= 9)//d>=9
                {
                    hocLuc[i] = "xuat sac";
                }
                else if (diem[i] >= 7.5)
                {
                    hocLuc[i] = "Gioi";
                }
                else if (diem[i] >= 6.5)
                {
                    hocLuc[i] = "Kha";
                }
                else if (diem[i] >= 5 && diem[i] < 6.5)
                {
                    hocLuc[i] = "Trung binh";
                }
                else
                {
                    hocLuc[i] = "Yeu";
                }
                Console.WriteLine("\t" + hocLuc);
            }
            Console.WriteLine("-----------------Danh sach sinh vien vua nhap-------------------");
            Console.WriteLine("TT\thoten\temail\tdiem\thocLuc");
            for (int i = 0; i < hoTen.Length; i++)
            {
                Console.Write((i + 1) + "\t" + hoTen[i] + "\t" + email[i] + "\t" + diem[i] + "\t" + hocLuc[i]);
            }
            Console.ReadKey();
        }
    }
}
